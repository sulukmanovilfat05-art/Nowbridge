package com.example.nowbridge

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BridgeListener : NotificationListenerService() {

    override fun onListenerConnected() { LiveNotifier.ensureChannel(this) }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (sbn.packageName !in Prefs.selected(this)) return
        val n = sbn.notification
        val remove = Prefs.removeOriginal(this)

        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) {
            if (remove) cancelNotification(sbn.key)
            return
        }
        if (sbn.isOngoing) return
        if (n.category == Notification.CATEGORY_CALL || n.category == Notification.CATEGORY_TRANSPORT) return

        LiveNotifier.show(this, sbn)
        if (remove) cancelNotification(sbn.key)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) LiveNotifier.clear(sbn.id)
    }
}
