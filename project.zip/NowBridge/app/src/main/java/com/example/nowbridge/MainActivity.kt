package com.example.nowbridge

import android.Manifest
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        LiveNotifier.ensureChannel(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Screen() } }
    }
}

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

private val GlassShape = RoundedCornerShape(24.dp)

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .clip(GlassShape)
            .background(Color.White.copy(alpha = 0.09f))
            .border(1.dp, Color.White.copy(alpha = 0.18f), GlassShape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Screen() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var selected by remember { mutableStateOf(Prefs.selected(ctx)) }
    var removeOrig by remember { mutableStateOf(Prefs.removeOriginal(ctx)) }
    var query by remember { mutableStateOf("") }
    var samsung by remember { mutableStateOf(Prefs.samsungExtras(ctx)) }
    var iconMode by remember { mutableStateOf(Prefs.iconMode(ctx)) }
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    val notifOn = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .filter { it.pkg != ctx.packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }

    fun save(s: Set<String>) { selected = s; Prefs.saveSelected(ctx, s) }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF0B0F1E), Color(0xFF151A33)))
        )
    ) {
        Box(Modifier.offset((-80).dp, (-40).dp).size(280.dp).background(Color(0xFF6C5CE7), CircleShape).blur(100.dp))
        Box(Modifier.align(Alignment.CenterEnd).offset(90.dp, 120.dp).size(260.dp).background(Color(0xFF00B4D8), CircleShape).blur(110.dp))
        Box(Modifier.align(Alignment.BottomStart).offset((-60).dp, 40.dp).size(240.dp).background(Color(0xFFE84393), CircleShape).blur(110.dp))

        LazyColumn(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Now Bridge", style = MaterialTheme.typography.headlineLarge, color = Color.White)
                Text("Сообщения из выбранных приложений — в Now Bar", color = Color.White.copy(0.7f))
            }
            item {
                Glass(Modifier.fillMaxWidth()) {
                    StatusRow("Доступ к уведомлениям", listenerOn) {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }
                    Spacer(Modifier.height(8.dp))
                    StatusRow("Показ уведомлений", notifOn) {
                        permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Затем: Настройки → Экран блокировки → Now Bar → Живые уведомления → включить Now Bridge",
                        color = Color.White.copy(0.6f), style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            item {
                Glass(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Удалять обычные уведомления", Modifier.weight(1f), color = Color.White)
                        Switch(removeOrig, { removeOrig = it; Prefs.setRemoveOriginal(ctx, it) })
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Старый режим Samsung (поля)", Modifier.weight(1f), color = Color.White)
                        Switch(samsung, { samsung = it; Prefs.setSamsungExtras(ctx, it) })
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Режим иконки (для проверки)", color = Color.White)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0, 1, 2, 3).forEach { m ->
                            FilterChip(
                                selected = iconMode == m,
                                onClick = { iconMode = m; Prefs.setIconMode(ctx, m) },
                                label = { Text("${m + 1}") }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = {
                        save(selected + apps.map { it.pkg }.filter { it in Prefs.popular })
                    }) { Text("Выбрать популярные мессенджеры") }
                    TextButton(onClick = { save(apps.map { it.pkg }.toSet()) }) { Text("Выбрать все приложения") }
                    TextButton(onClick = { save(emptySet()) }) { Text("Снять всё") }
                }
            }
            item {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Поиск приложения") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    shape = GlassShape
                )
            }
            items(apps.filter { query.isBlank() || it.label.contains(query, true) }, key = { it.pkg }) { app ->
                Glass(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val bmp = remember(app.pkg) { app.icon.toBitmap(96, 96).asImageBitmap() }
                        Image(bmp, null, Modifier.size(40.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(app.label, Modifier.weight(1f), color = Color.White)
                        Switch(app.pkg in selected, {
                            save(if (it) selected + app.pkg else selected - app.pkg)
                        })
                    }
                }
            }
        }
    }
}

@Composable
fun StatusRow(label: String, ok: Boolean, onFix: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text((if (ok) "✓ " else "✗ ") + label, Modifier.weight(1f),
            color = if (ok) Color(0xFF55EFC4) else Color(0xFFFF7675))
        if (!ok) Button(onClick = onFix) { Text("Включить") }
    }
}
