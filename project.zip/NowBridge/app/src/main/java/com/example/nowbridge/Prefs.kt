package com.example.nowbridge

import android.content.Context

object Prefs {
    val popular = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger", "org.telegram.messenger.web",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.instagram.android",
        "com.discord", "com.viber.voip", "com.facebook.orca", "com.snapchat.android",
        "org.thoughtcrime.securesms", "com.vkontakte.android", "com.google.android.apps.messaging",
        "com.samsung.android.messaging"
    )
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun selected(c: Context): Set<String> = sp(c).getStringSet("sel", emptySet())!!.toSet()
    fun saveSelected(c: Context, s: Set<String>) = sp(c).edit().putStringSet("sel", s).apply()
    fun iconMode(c: Context) = sp(c).getInt("im", 3)
    fun setIconMode(c: Context, v: Int) = sp(c).edit().putInt("im", v).apply()
    fun samsungExtras(c: Context) = sp(c).getBoolean("sx", false)
    fun setSamsungExtras(c: Context, v: Boolean) = sp(c).edit().putBoolean("sx", v).apply()
    fun removeOriginal(c: Context) = sp(c).getBoolean("rm", true)
    fun setRemoveOriginal(c: Context, v: Boolean) = sp(c).edit().putBoolean("rm", v).apply()
}
